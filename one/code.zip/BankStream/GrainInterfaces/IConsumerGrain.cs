using Orleans;

namespace GrainInterfaces
{
    public interface IConsumerGrain : IGrainWithGuidKey
    {
    }
}