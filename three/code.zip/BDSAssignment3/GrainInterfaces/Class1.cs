﻿using System;

namespace GrainInterfaces
{
    public class Class1
    {
    }
}
