﻿using System;

namespace Grains
{
    public class Class1
    {
    }
}
